<footer>
    <p>&copy; <?php echo date('Y'); ?> 
   <b><fade> Designed by Chandra Mohan & Subham Naha<b></fade></p>
</footer>
