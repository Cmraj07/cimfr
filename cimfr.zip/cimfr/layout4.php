<!DOCTYPE html>
<html>
<head>
    <title>Visitor Management Dashboard</title>
    <style>
        /* ... previous CSS styles ... */

        /* Additional CSS styles for displaying active passes */
        .activePassList {
            display: none;
            margin-top: 20px;
            text-align: center;
        }

        .activePassList table {
            width: 100%;
            border-collapse: collapse;
        }

        .activePassList th,
        .activePassList td {
            padding: 10px;
            border: 1px solid #ddd;
        }

        .activePassList th {
            background-color: #f1f1f1;
        }

        .activePassList td button {
            padding: 5px 10px;
            font-size: 12px;
            border-radius: 5px;
            cursor: pointer;
        }

        .activePassList td button.print {
            background-color: #4CAF50;
            color: #fff;
        }

        .activePassList td button.markOut {
            background-color: #f44336;
            color: #fff;
        }
    </style>
</head>
<body>
    <!-- ... previous HTML code ... -->

    <div id="generatePass" class="tabContent">
        <h2>Generate Gate Pass</h2>
        <!-- Form for generating gate pass -->
        <!-- ... -->
    </div>

    <div id="activePass" class="tabContent">
        <h2>Active Passes</h2>
        <div class="activePassList" id="activePassList">
            <table>
                <thead>
                    <tr>
                        <th>Gate Pass Number</th>
                        <th>Name</th>
                        <th>Valid Until</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Sample pass data, replace with actual data using JavaScript -->
                    <tr>
                        <td>GP001</td>
                        <td>John Doe</td>
                        <td>2023-07-05</td>
                        <td>
                            <button class="print" onclick="printActivePass('GP001')">Print</button>
                            <button class="markOut" onclick="markPassOut('GP001')">Mark Out</button>
                        </td>
                    </tr>
                    <tr>
                        <td>GP002</td>
                        <td>Jane Smith</td>
                        <td>2023-07-10</td>
                        <td>
                            <button class="print" onclick="printActivePass('GP002')">Print</button>
                            <button class="markOut" onclick="markPassOut('GP002')">Mark Out</button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    <div id="reports" class="tabContent">
        <h2>Generate Reports</h2>
        <!-- Form for generating reports -->
        <!-- ... -->
    </div>

    <script>
        // Function to open a specific tab
        function openTab(tabName) {
            var i, tabContent, tabButtons;

            // Hide all tab content
            tabContent = document.getElementsByClassName("tabContent");
            for (i = 0; i < tabContent.length; i++) {
                tabContent[i].style.display = "none";
            }

            // Deactivate all tab buttons
            tabButtons = document.getElementsByClassName("tab");
            for (i = 0; i < tabButtons.length; i++) {
                tabButtons[i].classList.remove("active");
            }

            // Show the selected tab content and activate the button
            document.getElementById(tabName).style.display = "block";
            document.getElementById(tabName + "Button").classList.add("active");

            if (tabName === "activePass") {
                displayActivePasses();
            }
        }

        // Function to display active passes
        function displayActivePasses() {
            // Simulated data, replace with actual data using JavaScript
            var activePasses = [
                { gatePassNumber: "GP001", name: "John Doe", validUntil: "2023-07-05" },
                { gatePassNumber: "GP002", name: "Jane Smith", validUntil: "2023-07-10" }
            ];

            var tableBody = document.querySelector("#activePassList tbody");
            tableBody.innerHTML = "";

            activePasses.forEach(function(pass) {
                var row = document.createElement("tr");

                var gatePassNumberCell = document.createElement("td");
                gatePassNumberCell.textContent = pass.gatePassNumber;
                row.appendChild(gatePassNumberCell);

                var nameCell = document.createElement("td");
                nameCell.textContent = pass.name;
                row.appendChild(nameCell);

                var validUntilCell = document.createElement("td");
                validUntilCell.textContent = pass.validUntil;
                row.appendChild(validUntilCell);

                var actionsCell = document.createElement("td");
                var printButton = document.createElement("button");
                printButton.textContent = "Print";
                printButton.className = "print";
                printButton.addEventListener("click", function() {
                    printActivePass(pass.gatePassNumber);
                });
                actionsCell.appendChild(printButton);

                var markOutButton = document.createElement("button");
                markOutButton.textContent = "Mark Out";
                markOutButton.className = "markOut";
                markOutButton.addEventListener("click", function() {
                    markPassOut(pass.gatePassNumber);
                });
                actionsCell.appendChild(markOutButton);

                row.appendChild(actionsCell);

                tableBody.appendChild(row);
            });

            document.getElementById("activePassList").style.display = "block";
        }

        // Function to print an active pass
        function printActivePass(gatePassNumber) {
            // Simulated printing operation
            alert("Printing Gate Pass: " + gatePassNumber);
        }

        // Function to mark a pass as 'OUT'
        function markPassOut(gatePassNumber) {
            // Simulated operation to mark the pass as 'OUT'
            alert("Marking Gate Pass as 'OUT': " + gatePassNumber);
        }
    </script>
</body>
</html>
