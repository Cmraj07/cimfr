<!DOCTYPE html>
<html>
<head>
    <title>Visitor Management Dashboard</title>
    <style>
        /* ... previous CSS styles ... */

        /* Additional CSS styles for gate pass details and printing */
        .gatePassDetailsForm {
            display: none;
            margin-top: 20px;
            text-align: center;
        }

        .gatePassDetailsForm input[type="text"],
        .gatePassDetailsForm input[type="date"],
        .gatePassDetailsForm select {
            padding: 10px;
            font-size: 16px;
            margin-bottom: 10px;
        }

        .gatePassDetailsForm button {
            padding: 10px 20px;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
        }

        .gatePass {
            display: none;
            margin-top: 20px;
            text-align: center;
        }

        .gatePass h2 {
            margin-top: 0;
        }

        .gatePass p {
            margin-bottom: 10px;
        }

        .gatePass button {
            padding: 10px 20px;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <!-- ... previous HTML code ... -->

    <div id="gatePassForm" class="registrationForm">
        <h2>Gate Pass Details</h2>
        <!-- Form for feeding gate pass details -->
        <!-- ... -->
    </div>

    <div id="registrationForm" class="registrationForm">
        <h2>Registration Form</h2>
        <!-- Form for visitor registration -->
        <!-- ... -->
    </div>

    <div class="gatePassDetailsForm" id="gatePassDetailsForm">
        <h2>Gate Pass Details</h2>
        <!-- Form for gate pass details -->
        <!-- ... -->
    </div>

    <div class="gatePass" id="gatePass">
        <h2>Gate Pass</h2>
        <p>Gate Pass Number: <span id="gatePassNumber"></span></p>
        <p>Name: <span id="gatePassName"></span></p>
        <p>Valid Until: <span id="gatePassValidUntil"></span></p>
        <button onclick="printGatePass()">Print Gate Pass</button>
    </div>

    <script>
        // Function to open a specific tab
        function openTab(tabName) {
            var i, tabContent, tabButtons;

            // Hide all tab content
            tabContent = document.getElementsByClassName("tabContent");
            for (i = 0; i < tabContent.length; i++) {
                tabContent[i].style.display = "none";
            }

            // Deactivate all tab buttons
            tabButtons = document.getElementsByClassName("tab");
            for (i = 0; i < tabButtons.length; i++) {
                tabButtons[i].classList.remove("active");
            }

            // Show the selected tab content and activate the button
            document.getElementById(tabName).style.display = "block";
            document.getElementById(tabName + "Button").classList.add("active");
        }

        // Function to search visitor by Aadhar number
        function searchVisitor() {
            var aadharNumber = document.getElementById("aadharInput").value;

            // Simulated check if visitor is registered
            var isRegistered = checkRegistration(aadharNumber);

            if (isRegistered) {
                openTab('gatePassForm');
            } else {
                openTab('registrationForm');
            }
        }

        // Function to print the gate pass
        function printGatePass() {
            var gatePassNumber = document.getElementById("gatePassNumber").textContent;
            var name = document.getElementById("gatePassName").textContent;
            var validUntil = document.getElementById("gatePassValidUntil").textContent;

            // Print the gate pass (simulated)
            alert("Printing Gate Pass:\n\nGate Pass Number: " + gatePassNumber + "\nName: " + name + "\nValid Until: " + validUntil);
        }
    </script>
</body>
</html>
