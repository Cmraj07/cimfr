<?php
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        
    }
?>
<!DOCTYPE html>
<html>
<head>
    <title>Visitor Management System</title>
    <style>
      header {
            text-align: right;
            padding: 10px;
        }
        
    </style>
</head>
<body>
    <header>
        <h3>Visitor Management System</h3>
    </header>
    
</body>
</html>
